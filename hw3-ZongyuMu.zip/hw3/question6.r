# Load packages
library(ISLR2)
library(nnet)

# Load data
data(Default)

# Convert variables
Default$default <- ifelse(Default$default == "Yes", 1, 0)
Default$student <- ifelse(Default$student == "Yes", 1, 0)

# Train-test split
set.seed(1)
train_id <- sample(1:nrow(Default), nrow(Default)/2)

train <- Default[train_id, ]
test  <- Default[-train_id, ]

# -----------------------------
# 1. Logistic Regression
# -----------------------------
glm_fit <- glm(default ~ balance + income + student,
               data = train,
               family = binomial)

glm_prob <- predict(glm_fit, newdata = test, type = "response")
glm_pred <- ifelse(glm_prob > 0.5, 1, 0)

glm_acc <- mean(glm_pred == test$default)

# -----------------------------
# 2. Neural Network (nnet)
# -----------------------------
train_nn <- train
test_nn  <- test

train_nn$default <- factor(train_nn$default, levels = c(0,1), labels = c("No","Yes"))
test_nn$default  <- factor(test_nn$default, levels = c(0,1), labels = c("No","Yes"))

set.seed(1)
nn <- nnet(default ~ balance + income + student,
           data = train_nn,
           size = 10,
           decay = 0.01,
           maxit = 200,
           trace = FALSE)

nn_pred <- predict(nn, test_nn, type = "class")

nn_acc <- mean(nn_pred == test_nn$default)

# -----------------------------
# Results
# -----------------------------
glm_acc
nn_acc
